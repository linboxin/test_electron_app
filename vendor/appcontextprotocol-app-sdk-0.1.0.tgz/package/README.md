# @appcontextprotocol/app-sdk

Embed ACP in your app. Register state, actions, and events once; every ACP-aware agent can then discover your app and drive it with typed calls instead of screenshots.

```ts
import { createAcpHost } from "@appcontextprotocol/app-sdk";
import { z } from "zod";

const acp = await createAcpHost({ appId: "com.acme.crm", name: "Acme CRM", version: "1.0.0" });

acp.exposeState("customers", { description: "All customers" }, () => store.customers);

acp.action("change_customer_plan", {
  description: "Change a customer's subscription plan",
  params: z.object({ customerId: z.string(), newPlan: z.enum(["free", "pro", "enterprise"]) }),
  confirm: true,
  handler: ({ customerId, newPlan }) => store.changePlan(customerId, newPlan),
});

acp.emit("customer.updated", { customerId: "c1" });
acp.notifyStateChanged("customers");

await acp.close(); // on shutdown
```

What the host does for you:

- Serves JSON-RPC over a `127.0.0.1` WebSocket on an ephemeral port, bearer-token authenticated.
- Publishes a discovery manifest at `~/.acp/apps/<appId>.json` (mode 0600) and removes it on `close()`.
- Validates arguments — fully via zod when you pass a zod v4 schema, structurally when you pass raw JSON Schema.
- Runs your `confirmer` before any `confirm: true` action; denial returns a structured `-32003` to the agent.
- Appends every call to the audit log at `~/.acp/logs/<appId>.jsonl`.

Electron apps: use the `@appcontextprotocol/app-sdk/electron` adapter (lifecycle wiring, dialog-based confirmer, renderer bridge). See [docs/INTEGRATION.md](../../docs/INTEGRATION.md).
