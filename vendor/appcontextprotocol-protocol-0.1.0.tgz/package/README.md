# @appcontextprotocol/protocol

Wire-level building blocks shared by every ACP package:

- **JSON-RPC 2.0 framing** — `createRequest` / `createNotification` / `createSuccess` / `createError`, `parseMessage`, and type guards.
- **Protocol types** — `DescribeResult`, `ActionDescriptor`, `CallResult`, method/notification name constants, `PROTOCOL_VERSION`.
- **Error codes** — `ErrorCodes` (-32001…-32005) plus `AcpCallError` / `AcpParseError`.
- **Discovery registry** — read/write `~/.acp/apps/<appId>.json` manifests with pid-liveness checks (`writeRegistration`, `readRegistrations`, …). Override the root dir with `ACP_HOME`.
- **`validateArgs`** — minimal structural JSON Schema validation (required keys, primitive types, enums).

The wire format is plain JSON Schema and JSON-RPC — no zod types cross the wire, so non-TypeScript clients can implement the protocol from [PROTOCOL.md](../../PROTOCOL.md).

Apps embed [`@appcontextprotocol/app-sdk`](../app-sdk); agents use [`@appcontextprotocol/client`](../client) or the [`acp-mcp`](../mcp-bridge) bridge.
